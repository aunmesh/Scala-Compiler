Grp 3
Final Project
Steps to compile:

1. make
2. bin/scalac test/filename

