object Demo_array{

	def main():Unit = {
	var i:Int = 0;
	var m:Int = 0;
	var c:Int = 15;
	var p:Array[Int] = new Array[Int](10);

	m = 10;

	for(i <- 0 to m by 2){
		c += 2*i;
		p[i] = c;
		println(p[i]);
	}
	println(c);

	}
}
