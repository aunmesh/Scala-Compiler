object Demo_if_else{

	def main(args: Array[String]): Unit ={
		var i: Int = 0;
		read(i);
		if (i <= 3){
			i+=10;}
		if (i >= 2){
			i-=1;}
		else{
			i=1;}
		println(i);
	}

}
