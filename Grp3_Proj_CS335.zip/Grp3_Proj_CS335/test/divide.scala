object Program {
	def main():Int = {
		var n:Int = 0;
		var m:Int = 0;
		var l:Int = 0;
		m = 2;
		n = 3;
		l = m/n;

		println(l);
	}
}
