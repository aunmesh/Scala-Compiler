object Demo_loop{
	def main():Unit = {
	var i:Int = 0;
	var m:Int = 0;
	var n:Int = 0;
	m = 4;	

	while(i <= m){
		read(n);
		n = n *2;
		println(n);
		i += 1;
	}
}
}
