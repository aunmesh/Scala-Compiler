object Demo_do_while{
   def main(args: Array[String]) {
      var a:Int = 10;

      do {
         println(a);
         a += 5;
         println(a);
      }
      while(a < 20)
   }
}
