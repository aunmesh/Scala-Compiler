object Demo_for{
	def main():Unit = {
	var i:Int = 0;
	var m:Int = 0;
	var c:Int = 15;

	m = 10;

	for(i <- 2 to m by 4){
		c += 1;
	}
	println(c);

	}
}
